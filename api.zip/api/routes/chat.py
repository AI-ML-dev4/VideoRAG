from fastapi import APIRouter
from pydantic import BaseModel

from rag.llm import ask_rag

router = APIRouter()


class ChatRequest(BaseModel):
    query: str
    video_name: str


@router.post("/chat")
def chat(request: ChatRequest):
    answer = ask_rag(request.query, request.video_name)

    return {
        "answer": answer
    }